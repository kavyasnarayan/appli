package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class Service extends Employee implements EmployeeService{
	
	public String insuranceScheme;
	public Service(){
		
	}
	
	public String schemeA()
	{
		System.out.println("Scheme A");
		String str1 = "schemeA";
		return str1;
	}
	
	public String schemeB()
	{
		System.out.println("Scheme B");
		String str2 = "schemeA";
		return str2;
	}
	
	public String schemeC()
	{
		System.out.println("Scheme C");
		String str3 = "schemeA";
		return str3;
	}
	
	public String cal(double salary){
	
	if( salary > 5000 && salary < 20000 ){
		String str6 = "Programmer";
		insuranceScheme = schemeA();
	 return str6;
	}
	else if(salary >= 20000 && salary < 40000 ){
		String str5 ="Programmer";
		insuranceScheme = schemeB();
		return str5;
	}
	else if(salary >= 40000){
	 String str  = "Manager";
	insuranceScheme = schemeC();
		return str;
	}
	else{
	 String str = "Clerk";
	insuranceScheme = "No Scheme";
		return str;
		
	}
	
}
}