package com.cg.eis.service;

public interface EmployeeService {
	public String schemeA();
	public String schemeB();
	public String schemeC();
	public String cal(double salary);

}
