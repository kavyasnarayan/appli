package com.cg.sms.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.dao.IStudentDao;
import com.cg.sms.dao.StudentDaoImpl;
import com.cg.sms.exception.StudentException;

public class StudentServiceImpl implements IStudentService {

	public boolean studentValidation(StudentDTO student) throws StudentException {

		String errorMessage = "";
		String studentName = null;
		Double fees = 0.0;
		String mobileNumber = null;

		/*************************************************************************************************************/
		// Validating Student Name
		/**************************************************************************************************************/
		studentName = student.getStudentName();
		Pattern namepattern = Pattern.compile("^[A-Z][A-Za-z]{3,10}$");
		Matcher namematcher = namepattern.matcher(studentName);
		if (!(namematcher.matches())) {
			errorMessage += "\nStudent Name Should start with Capital letter and minimum 3 characters long.";
		}

		/*************************************************************************************************************/
		// Validating mobile number
		/**************************************************************************************************************/
		mobileNumber = student.getMobileNumber();
		Pattern mobilePattern = Pattern.compile("^\\d{10}$");
		Matcher mobileMatcher = mobilePattern.matcher(mobileNumber);
		if (!(mobileMatcher.matches())) {
			errorMessage += "\nMobile Number Should be in 10 digit";
		}

		/*************************************************************************************************************/
		// Validating fees
		/**************************************************************************************************************/
		fees=student.getFees();
		if(fees<=0) {
			errorMessage += "\nfees should be positive number.";
		}
		
		if (!errorMessage.isEmpty()) {
			throw new StudentException(errorMessage);

		}
			
		return true;
		
	}
	
	/*******************************
	 * 
	 * Roll Number validation
	 * *************************************/
	

	@Override
	public String addStudent(StudentDTO student) throws StudentException {
	
		IStudentDao dao=new StudentDaoImpl();
		return dao.insertStudentDetails(student);
	}

	@Override
	public StudentDTO showdetails(String rollno) throws StudentException {
		
		return new StudentDaoImpl().viewStudentDetails(rollno);
	}

	@Override
	public boolean validateRollNo(String rollno) {
		
			boolean result=false;
			Pattern rollPattern = Pattern.compile("\\d{2}");
			Matcher rollMatcher = rollPattern.matcher(rollno);

			if (rollMatcher.matches()){
			result=true;
			}
			return result;	

	}

	@Override
	public List<StudentDTO> retrieveStudentDetails() throws StudentException {
	
		return new StudentDaoImpl().retrieveStudentDetails();
	}
}
