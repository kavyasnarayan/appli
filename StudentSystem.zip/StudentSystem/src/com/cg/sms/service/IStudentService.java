package com.cg.sms.service;

import java.util.List;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;

public interface IStudentService {
	String addStudent(StudentDTO student) throws StudentException;
	StudentDTO showdetails(String rollno) throws StudentException;
	public boolean  validateRollNo(String rollno) ;
	List<StudentDTO> retrieveStudentDetails() throws StudentException;
}
