package com.cg.sms.dao;

public class StudentQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO StudentDetails VALUES(RollNo_sequence.NEXTVAL,?,?,?,?)";
	public static final String DONARID_QUERY_SEQUENCE="SELECT RollNo_sequence.CURRVAL FROM DUAL";
	public static final String RETRIVE_ALL_QUERY="SELECT rollno,studentname,fees,doj,mobileNumber FROM StudentDetails";
	public static final String VIEW_DONAR_DETAILS_QUERY="SELECT rollno,studentName,fees,doj,mobileNumber FROM StudentDetails WHERE  rollNo=?";

}
