package com.cg.sms.dao;

import java.util.List;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;

public interface IStudentDao {

	public String insertStudentDetails(StudentDTO student) throws StudentException;
	
	public StudentDTO viewStudentDetails(String rollno) throws StudentException;
	
	public List<StudentDTO> retrieveStudentDetails() throws StudentException;
}
