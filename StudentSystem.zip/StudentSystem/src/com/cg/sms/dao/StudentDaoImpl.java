package com.cg.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;
import com.cg.sms.util.DBConnection;

public class StudentDaoImpl implements IStudentDao {
	/*********************************************************************
	 * To insert student details
	 *******************************************************************/
	@Override
	public String insertStudentDetails(StudentDTO student) throws StudentException {
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		ResultSet resultSet = null;
		int query = -1;
		String rollno = "";
		try {
			connection.setAutoCommit(false);
			preparedStatement = connection.prepareStatement(StudentQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, student.getStudentName());
			preparedStatement.setDouble(2, student.getFees());
			preparedStatement.setDate(3, java.sql.Date.valueOf(student.getDateOfJoining()));
			preparedStatement.setString(4, student.getMobileNumber());
			query = preparedStatement.executeUpdate();

			if (query == 1) {
				connection.commit();
				preparedStatement1 = connection.prepareStatement(StudentQueryMapper.DONARID_QUERY_SEQUENCE);
				resultSet = preparedStatement1.executeQuery();
				if (resultSet.next()) {
					rollno = resultSet.getInt(1) + "";
				}
			}

		} catch (SQLException exception) {
			try {
				connection.rollback();
			} catch (SQLException e) {
			}
			throw new StudentException(exception.getMessage());
		} finally {
			if (preparedStatement != null && preparedStatement1 != null && connection != null) {
				try {
					resultSet.close();
					preparedStatement.close();
				} catch (SQLException exception) {
					throw new StudentException(exception.getMessage());
				}
			}
		}

		return rollno;
	}
	/******************************************************************
	 * To view Student details with respect to roll number
	 * ***************************************************************/

	@Override
	public StudentDTO viewStudentDetails(String rollno) throws StudentException {

		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		StudentDTO student = null;
		try {
			preparedStatement = connection.prepareStatement(StudentQueryMapper.VIEW_DONAR_DETAILS_QUERY);
			preparedStatement.setString(1, rollno);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				student = new StudentDTO();
				student.setRollNo(resultSet.getString(1));
				student.setStudentName(resultSet.getString(2));
				student.setFees(resultSet.getDouble(3));
				student.setDateOfJoining(resultSet.getDate(4).toLocalDate());
				student.setMobileNumber(resultSet.getString(5));
			}
		} catch (SQLException exception) {
			throw new StudentException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
			} catch (SQLException exception) {
				throw new StudentException(exception.getMessage());
			}
		}

		return student;
	}
	/***************************************************************
	 * To retrieve student details
	 * *************************************************************/

	@Override
	public List<StudentDTO> retrieveStudentDetails() throws StudentException {

		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<StudentDTO> list = new ArrayList<StudentDTO>();
		try {
			preparedStatement = connection.prepareStatement(StudentQueryMapper.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				StudentDTO student = new StudentDTO();
				student.setRollNo(resultSet.getString(1));
				student.setStudentName(resultSet.getString(2));
				student.setFees(resultSet.getDouble(3));
				student.setDateOfJoining(resultSet.getDate(4).toLocalDate());
				student.setMobileNumber(resultSet.getString(5));
				list.add(student);

			}
		} catch (SQLException expection) {
			throw new StudentException(expection.getMessage());
		} finally {
			if (preparedStatement != null && connection != null && resultSet != null) {
				try {
					resultSet.close();
					preparedStatement.close();
				} catch (SQLException exception) {
					throw new StudentException(exception.getMessage());
				}
			}
		}

		return list;
	}

}
