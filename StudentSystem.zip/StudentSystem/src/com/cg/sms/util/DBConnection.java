package com.cg.sms.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBConnection  {
    private static Connection connection=null;
    private static Properties properties=new Properties();
	
	
	public static Connection getConnection(){
		if(connection==null)
	try{
		InputStream inputStream = new FileInputStream("resources/dbprop.properties");
        properties.load(inputStream);
        String username=properties.getProperty("username");
        String password=properties.getProperty("password");
        String url=properties.getProperty("url");
        inputStream.close();
        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
        connection=DriverManager.getConnection(url, username, password);
        connection.setAutoCommit(false);
		}catch(SQLException e){
		e.printStackTrace();
		}catch(FileNotFoundException exception){
			System.err.println("Please upload a file");
		}
		catch(IOException e1){
			e1.printStackTrace();
}
	return connection;
	
}

}
