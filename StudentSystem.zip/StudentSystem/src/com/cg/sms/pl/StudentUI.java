package com.cg.sms.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.sms.bean.StudentDTO;
import com.cg.sms.exception.StudentException;
import com.cg.sms.service.IStudentService;
import com.cg.sms.service.StudentServiceImpl;

public class StudentUI {

	public static void main(String[] args) throws StudentException {
		Scanner scanner = new Scanner(System.in);
		String option = "";
		StudentServiceImpl serviceImpl = null;
		StudentDTO student = null;
		IStudentService service = null;
		do {

			System.out.println("STUDNET MANAGEMENT SYSTEM\n");
			System.out.println("_____________________________");
			System.out.println("Enter Your Choice from 1 to 4");
			System.out.println("\nOption 1:Add student details");
			System.out.println("\nOption 2:View Student details");
			System.out.println("\nOption 3:Fetch student details");
			System.out.println("\nOption 4:Exit");
			option = scanner.next();
			switch (option) {
			case "1":
				serviceImpl = new StudentServiceImpl();
				service = new StudentServiceImpl();
				student = new StudentDTO();
				System.out.println("Add Deatils");
				System.out.println("\nEnter Student Name");
				String name = scanner.next();
				student.setStudentName(name);

				/*
				 * System.out.println("Enter Student roll number\n"); String
				 * rollno=scanner.next();
				 */

				System.out.println("\nEnter Student fees");
				double fees = scanner.nextDouble();
				student.setFees(fees);

				System.out.println("\nEnter student date of joining");
				String doj = scanner.next();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date = LocalDate.parse(doj, formatter);
				student.setDateOfJoining(date);

				System.out.println("\nEnter student Mobile number");
				String number = scanner.next();
				student.setMobileNumber(number);

				try {
					if (serviceImpl.studentValidation(student)) {
						System.out.println("Validated");
						System.out.println("Student record inserted successfully \n student id is :: "
								+ service.addStudent(student));
					}
				} catch (StudentException exp) {

					System.err.println(exp.getMessage() + " Please try again");

				}
				break;
			case "2":
				service = new StudentServiceImpl();
				System.out.println("View Student details");
				System.out.println("\nEnter Student Rollnumber");
				String rollno = scanner.next();
				while (true) {
					if (serviceImpl.validateRollNo(rollno)) {
						break;
					} else {
						System.err.println("Please enter valid student number,Try again");
						System.out.println("\nEnter student Roll number");
						rollno = scanner.next();
					}
				}
				student = service.showdetails(rollno);
				if (student != null) {
					System.out.println("Student Details");
					System.out.println("Student Name :" + student.getStudentName() + "Student Roll Number:"
							+ student.getRollNo() + "Student fees:" + student.getFees() + "Student Date Of Joining"
							+ student.getDateOfJoining() + "Student Mobile Number" + student.getMobileNumber());
				} else {
					System.err.println("No student records are inserted still");
				}

				break;
			case "3":
				System.out.println("Fetch Student Details");
				List<StudentDTO> list=new ArrayList<StudentDTO>();
				list=service.retrieveStudentDetails();
				for(StudentDTO studentDTO :list) {
					System.out.println("Student Roll Number : "+studentDTO.getRollNo()
					+"Student Name :"+studentDTO.getStudentName()+
					"Student fees :"+studentDTO.getFees()+
					"Student DOB :"+studentDTO.getFees()+
					"Student Mobile Number"+studentDTO.getMobileNumber());
				}
				
				break;
			case "4":
				System.out.println("Exit");
				System.out.println("__________________________________________________");
				System.out.println("Application ended Thank You");
				break;
			default:
				System.out.println("Please choose your option from 1 to 4");
				break;
			}
			System.out.println("\nDo you want to continue? (Y/N)");
			char decision = scanner.next().charAt(0);
			if (decision == 'Y') {
				continue;
			} else {
				break;
			}
		} while (!option.equals("4"));
		scanner.close();
	}
}
