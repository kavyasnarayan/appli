package com.cg.sms.exception;

public class StudentException extends Exception {
	private static final long serialVersionUID = 726264577455921591L;
	
	public StudentException(String message) {
		super(message);
		
	}

	

}
